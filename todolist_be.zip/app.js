const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const indexRouter = require("./routes/index"); 
const app = express();
const cors = require('cors');
app.use(cors());
require('dotenv').config();
const MONGODB_URI_PROD=process.env.MONGODB_URI_PROD
console.log("mogo",MONGODB_URI_PROD);


// 미들웨어 설정
app.use(bodyParser.json());  // JSON 형식의 요청을 처리
app.use("/api", indexRouter);  // /api로 시작하는 요청은 모두 indexRouter로 전달

// MongoDB 연결 URI
const mongoURI =MONGODB_URI_PROD;

// MongoDB 연결 설정
mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log("Mongoose connected");
    })
    .catch(err => {
        console.error("DB connection failed:", err.message);  // 오류 메시지 출력
    });

// 서버 시작
app.listen(process.env.PORT || 5000, () => {
    console.log("Server running on port 5000");
});
